import tkinter as tk


def create_popup(root):
    win = tk.Toplevel(root)
    win.title("helo")
    tk.Label(win, text="helo your computer has vajrus").pack(padx=20, pady=10)
    def on_ok():
        create_popup(root)
    tk.Button(win, text="OK", command=on_ok).pack(pady=(0,10))


if __name__ == '__main__':
    root = tk.Tk()
    root.withdraw()
    create_popup(root)
    root.mainloop()
